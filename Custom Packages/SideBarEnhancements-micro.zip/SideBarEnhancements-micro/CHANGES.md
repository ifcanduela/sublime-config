## GOALS

Provides the following extra sidebar context menu entries:

- `Copy`
- `Cut`
- `Paste`
- `Rename`

And changes the `New File` entry to automatically ask for a name.
